// storing data


export class Game{
  id: number;
  gName: string;
  gprice:number;
  }
  